x=4
y=5
a=3*(x+y)

print(a)
