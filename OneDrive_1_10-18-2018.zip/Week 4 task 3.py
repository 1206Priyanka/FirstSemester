radius = float(input("Enter the radius: "))
