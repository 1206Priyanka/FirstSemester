radius = int(input("Radius:"))
pi = 3.14
area = pi*radius**2
print(area)
